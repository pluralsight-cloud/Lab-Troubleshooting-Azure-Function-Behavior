using System;
using System.IO;
using Microsoft.Extensions.Logging;

public static void Run(
    Stream inputBlob,
    Stream outputBlob,
    string name,
    ILogger log)
{
    log.LogInformation($"ProcessImage started for blob: {name}");

    if (inputBlob == null)
        throw new ArgumentNullException(nameof(inputBlob));

    if (inputBlob.Length == 0)
        throw new InvalidOperationException($"The uploaded blob '{name}' is empty.");

    inputBlob.CopyTo(outputBlob);

    log.LogInformation(
        $"ProcessImage completed for blob: {name}. Bytes copied: {inputBlob.Length}");
}
